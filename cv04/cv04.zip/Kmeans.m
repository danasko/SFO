% k-means quantization
k = 10;

I = imread('peppers.png');
I = im2double(I);
[X,Y] = meshgrid(1:size(I,2), 1:size(I,1));

A = reshape(I, [], 3);
% B = zeros(size(A,1), k);
% B(:,1:3) = A(:,1:3);

X = (X-min(X(:)))/(max(X(:)) - min(X(:)));
Y = (Y-min(Y(:)))/(max(Y(:)) - min(Y(:)));

% B(:,4) = reshape(X, [], 1);
% B(:,5) = reshape(Y, [], 1);

[~, colors] = kmeans(A, k);

% res = reshape(res, size(I,1), size(I,2));
res = pdist2(A(:,1:3), colors(:,1:3));

[~, indMin] = min(res,[],2);
imgVecNewQ = colors(indMin,1:3);  %quantizing

imgNewQ=I;
imgNewQ(:,:,1)=reshape(imgVecNewQ(:,1),size(I(:,:,1)));
imgNewQ(:,:,2)=reshape(imgVecNewQ(:,2),size(I(:,:,1)));
imgNewQ(:,:,3)=reshape(imgVecNewQ(:,3),size(I(:,:,1)));

imshow(imgNewQ)